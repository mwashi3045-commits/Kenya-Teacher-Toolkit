# Kenya Teacher Toolkit — MVP

A mobile-friendly, static teacher productivity web app.

## Included
- Lesson Plan Generator
- Assessment Template Generator
- Learner Score Calculator
- Individual Learner Report
- Print-friendly output
- Dark mode
- No database or login required

## Run locally
Open `index.html` in a browser.

## Put it on GitHub
1. Create a GitHub repository, e.g. `kenya-teacher-toolkit`.
2. Upload `index.html`, `style.css`, `app.js`, and `README.md`.
3. In GitHub, open **Settings → Pages**.
4. Select the main branch and root folder.
5. Save. GitHub will provide the public website address.

## Next monetization version
Add:
- user accounts
- saved lesson plans
- Word/PDF export
- AI-assisted generation
- premium document packs
- school subscriptions
- M-Pesa payment integration
- usage limits for free accounts
- admin dashboard

Important: the current version is a functional MVP/template generator, not a complete AI service or payment system.
