const $=id=>document.getElementById(id);
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));document.querySelectorAll(".panel").forEach(x=>x.classList.remove("active"));b.classList.add("active");$(b.dataset.tab).classList.add("active")});
$("darkBtn").onclick=()=>document.body.classList.toggle("dark");
$("date").value=new Date().toISOString().slice(0,10);

function esc(v){return String(v||"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
function val(id){return esc($(id).value)}

function generateLesson(){
const html=`<h2>LESSON PLAN</h2><table class="doc"><tr><td><b>School:</b> ${val("school")}</td><td><b>Teacher:</b> ${val("teacher")}</td></tr><tr><td><b>Grade:</b> ${val("grade")}</td><td><b>Learning Area:</b> ${val("area")}</td></tr><tr><td><b>Week:</b> ${val("week")}</td><td><b>Lesson:</b> ${val("lessonNo")}</td></tr><tr><td><b>Strand:</b> ${val("strand")}</td><td><b>Sub-strand:</b> ${val("substrand")}</td></tr><tr><td><b>Duration:</b> ${val("duration")}</td><td><b>Date:</b> ${val("date")}</td></tr></table><h3>Specific Learning Outcomes</h3><p>${val("outcomes")}</p><h3>Resources</h3><p>${val("resources")}</p><h3>Introduction / Previous Knowledge</h3><p>${val("intro")}</p><h3>Lesson Activities</h3><p>${val("activities")}</p><h3>Assessment / Evidence of Learning</h3><p>${val("assessmentText")}</p><h3>Reflection / Remarks</h3><p>${val("reflection")}</p>`;
$("lessonPreview").innerHTML=html;
}
function generateAssessment(){
let n=Math.max(1,Math.min(30,Number($("qCount").value)||10)), marks=Number($("assMarks").value)||20;
let rows=Array.from({length:n},(_,i)=>`<p><b>${i+1}.</b> ____________________________________________________________________ <span>(${Math.max(1,Math.round(marks/n))} mark${marks/n==1?"":"s"})</span></p>`);
$("assessmentPreview").innerHTML=`<h2>ASSESSMENT</h2><p><b>Learning Area:</b> ${val("assArea")} &nbsp; <b>Grade:</b> ${val("assGrade")}</p><p><b>Topic:</b> ${val("assTopic")} &nbsp; <b>Total Marks:</b> ${marks}</p><hr>${rows.join("")}<h3>Teacher's Notes</h3><p>____________________________________________________________</p>`;
}
let learnerCount=0;
function addLearner(){learnerCount++;const d=document.createElement("div");d.className="learner-row";d.dataset.id=learnerCount;d.innerHTML=`<input class="lname" placeholder="Learner ${learnerCount}"><input class="lmark" type="number" min="0" placeholder="Mark"><button class="remove" onclick="this.parentElement.remove()">×</button>`;$("learners").appendChild(d)}
for(let i=0;i<5;i++)addLearner();
function band(p){if(p>=80)return"Exceeding Expectations";if(p>=60)return"Meeting Expectations";if(p>=40)return"Approaching Expectations";return"Below Expectations"}
function calculateScores(){
let rows=[...document.querySelectorAll(".learner-row")];let html=`<h2>LEARNER SCORE REPORT</h2><table border="1" cellpadding="7" cellspacing="0" width="100%"><tr><th>Learner</th><th>Mark</th><th>Percentage</th><th>Performance Band</th></tr>`;
rows.forEach(r=>{let name=esc(r.querySelector(".lname").value||"Unnamed"),m=Number(r.querySelector(".lmark").value)||0,p=Math.min(100,m);html+=`<tr><td>${name}</td><td>${m}</td><td>${p.toFixed(1)}%</td><td>${band(p)}</td></tr>`});html+="</table>";$("scorePreview").innerHTML=html}
function generateReport(){let m=Number($("rMarks").value)||0,t=Number($("rTotal").value)||100,p=t?Math.min(100,m/t*100):0;$("reportPreview").innerHTML=`<h2>INDIVIDUAL LEARNER REPORT</h2><p><b>Learner:</b> ${val("rName")}</p><p><b>Grade:</b> ${val("rGrade")} &nbsp; <b>Term:</b> ${val("rTerm")}</p><p><b>Learning Area:</b> ${val("rArea")}</p><table border="1" cellpadding="8" cellspacing="0" width="100%"><tr><th>Marks</th><th>Percentage</th><th>Performance Band</th></tr><tr><td>${m}/${t}</td><td>${p.toFixed(1)}%</td><td>${band(p)}</td></tr></table><h3>Teacher's Comment</h3><p>${val("rComment")}</p><br><p>Teacher: ____________________ &nbsp;&nbsp; Date: ____________________</p>`}
function printSection(id){if(!$("."+id)&&!$(id).innerHTML.trim())return;window.print()}
